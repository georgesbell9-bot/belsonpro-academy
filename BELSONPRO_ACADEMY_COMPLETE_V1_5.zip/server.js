require("dotenv").config();
const express=require("express"), path=require("path"), session=require("express-session"), bcrypt=require("bcryptjs"), Database=require("better-sqlite3"), multer=require("multer");
const app=express(), db=new Database("belsonpro.db");
app.use(express.json()); app.use(express.urlencoded({extended:true}));
app.use(session({secret:process.env.SESSION_SECRET||"dev-secret",resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:"lax"}}));
app.use(express.static(path.join(__dirname,"public")));
db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,email TEXT UNIQUE,password TEXT,role TEXT DEFAULT 'customer',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY,title TEXT,category TEXT,description TEXT,price INTEGER,file TEXT,cover TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY,user_id INTEGER,total INTEGER,status TEXT DEFAULT 'pending',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS order_items(id INTEGER PRIMARY KEY,order_id INTEGER,product_id INTEGER,price INTEGER);`);
const count=db.prepare("SELECT COUNT(*) c FROM products").get().c;
if(!count){const ins=db.prepare("INSERT INTO products(title,category,description,price,file,cover) VALUES(?,?,?,?,?,?)");
[
["Analyse mathématique pour ingénieurs","Mathématiques","Cours, méthodes et exercices.",5000,"","📐"],
["Algèbre linéaire — cours & exercices","Mathématiques","Espaces vectoriels, matrices et applications linéaires.",4500,"","🔢"],
["Physique générale pour ingénieurs","Physique","Mécanique, électricité et bases de physique appliquée.",6000,"","⚛️"],
["Chimie générale pour ingénieurs","Chimie","Cours, réactions et exercices d'application.",5500,"","⚗️"],
["Mécanique des solides — exercices corrigés","Ingénierie","Cinématique, torseurs et champ des accélérations.",6500,"","⚙️"],
["Pack révision sciences de l'ingénieur","Exercices","Fiches et exercices pour réviser.",9000,"","📝"]
].forEach(x=>ins.run(...x));}
async function ensureAdmin(){let u=db.prepare("SELECT * FROM users WHERE email=?").get(process.env.ADMIN_EMAIL||"admin@belsonpro.com");if(!u)db.prepare("INSERT INTO users(email,password,role) VALUES(?,?,?)").run(process.env.ADMIN_EMAIL||"admin@belsonpro.com",await bcrypt.hash(process.env.ADMIN_PASSWORD||"ChangeMe123!",10),"admin");}
ensureAdmin();
const upload=multer({dest:path.join(__dirname,"uploads")});
function auth(req,res,next){if(!req.session.user)return res.status(401).json({error:"Connexion requise"});next()}
function admin(req,res,next){if(req.session.user?.role!=="admin")return res.status(403).json({error:"Accès administrateur refusé"});next()}
app.get("/api/products",(req,res)=>res.json(db.prepare("SELECT id,title,category,description,price,cover FROM products ORDER BY id DESC").all()));
app.post("/api/register",async(req,res)=>{try{const {email,password}=req.body;if(!email||!password||password.length<8)return res.status(400).json({error:"E-mail et mot de passe (8 caractères minimum) requis"});const hash=await bcrypt.hash(password,10);const r=db.prepare("INSERT INTO users(email,password) VALUES(?,?)").run(email.toLowerCase(),hash);req.session.user={id:r.lastInsertRowid,email:email.toLowerCase(),role:"customer"};res.json({ok:true,user:req.session.user})}catch(e){res.status(400).json({error:"Cet e-mail est déjà utilisé"})}});
app.post("/api/login",async(req,res)=>{const u=db.prepare("SELECT * FROM users WHERE email=?").get((req.body.email||"").toLowerCase());if(!u||!(await bcrypt.compare(req.body.password||"",u.password)))return res.status(401).json({error:"Identifiants incorrects"});req.session.user={id:u.id,email:u.email,role:u.role};res.json({ok:true,user:req.session.user})});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",(req,res)=>res.json({user:req.session.user||null}));
app.post("/api/orders",auth,(req,res)=>{const ids=[...new Set((req.body.productIds||[]).map(Number))];if(!ids.length)return res.status(400).json({error:"Panier vide"});const ps=ids.map(id=>db.prepare("SELECT * FROM products WHERE id=?").get(id)).filter(Boolean);const total=ps.reduce((s,p)=>s+p.price,0);const tx=db.transaction(()=>{const o=db.prepare("INSERT INTO orders(user_id,total,status) VALUES(?,?,?)").run(req.session.user.id,total,"paid_demo");const oi=db.prepare("INSERT INTO order_items(order_id,product_id,price) VALUES(?,?,?)");ps.forEach(p=>oi.run(o.lastInsertRowid,p.id,p.price));return o.lastInsertRowid});const orderId=tx();res.json({ok:true,orderId,total,message:"Commande enregistrée en mode démonstration. Branche un vrai prestataire de paiement avant toute vente."})});
app.get("/api/orders",auth,(req,res)=>res.json(db.prepare("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC").all(req.session.user.id)));
app.get("/api/admin/products",admin,(req,res)=>res.json(db.prepare("SELECT * FROM products ORDER BY id DESC").all()));
app.post("/api/admin/products",admin,upload.single("file"),(req,res)=>{const {title,category,description,price}=req.body;const file=req.file?req.file.filename:"";const r=db.prepare("INSERT INTO products(title,category,description,price,file,cover) VALUES(?,?,?,?,?,?)").run(title,category,description,Number(price),file,"📚");res.json({ok:true,id:r.lastInsertRowid})});
app.delete("/api/admin/products/:id",admin,(req,res)=>{db.prepare("DELETE FROM products WHERE id=?").run(req.params.id);res.json({ok:true})});
app.get("/api/admin/orders",admin,(req,res)=>res.json(db.prepare("SELECT o.*,u.email FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC").all()));
app.listen(process.env.PORT||3000,()=>console.log("BELSONPRO ACADEMY: http://localhost:"+(process.env.PORT||3000)));
